#Requires -Version 5.1
<#
    hugo-blog-manager : run `hugo server` for local preview.

    Long-running foreground process. Start it in a background exec session, then let
    the USER confirm the result in their browser (do not "verify" localhost with HTTP calls).

    Usage:
        powershell -NoProfile -File preview.ps1 -SitePath "D:\blogs\myblog" -Port 1313
        powershell -NoProfile -File preview.ps1 -SitePath "D:\blogs\myblog" -Drafts -DryRun
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$SitePath,
    [int]$Port = 1313,
    [switch]$Drafts,
    [string]$BindAddress = '127.0.0.1',
    [string]$Image = 'hugomods/hugo:exts',
    [switch]$DryRun
)

. (Join-Path $PSScriptRoot '_common.ps1')

$sitePath = [System.IO.Path]::GetFullPath($SitePath)
if (-not (Test-Path -LiteralPath $sitePath)) { Write-Fail "Site not found: $sitePath" 4 }

$status = Get-HugoStatus
if ($status.Mode -eq 'none') {
    Write-Fail "hugo is not available. Run check_env.ps1, then ask the user to choose Local or Docker install." 1
}

# In container mode the server must listen on 0.0.0.0 inside the container,
# with the port published on the host loopback.
$innerBind = $BindAddress
$extra = @()
if ($status.Mode -eq 'docker') {
    $innerBind = '0.0.0.0'
    $extra = @('-p', ("{0}:{1}:{1}" -f $BindAddress, $Port))
}

$hugoArgs = @('server', '--port', "$Port", '--bind', $innerBind)
if ($Drafts) { $hugoArgs += '-D' }

Write-Output ("hugo mode: {0}" -f $status.Mode)
Write-Output ("Preview (foreground): http://{0}:{1}/  <- the user opens this in their browser" -f $BindAddress, $Port)
Write-Output 'Stop it by terminating the background session when the user is done.'

Invoke-Hugo -SitePath $sitePath -MountPath $sitePath -Image $Image `
    -ExtraDockerArgs $extra -HugoArgs $hugoArgs -DryRun:$DryRun
