#Requires -Version 5.1
<#
    hugo-blog-manager : environment check. Read-only, installs nothing.
    Exit codes: 0 = ready, 1 = hugo missing, 2 = git missing, 3 = both missing.
#>
[CmdletBinding()]
param([switch]$Json)

. (Join-Path $PSScriptRoot '_common.ps1')

$hugo = Get-HugoStatus
$git = Get-GitExe
$docker = Test-DockerEngine
$winget = Resolve-Tool -Name 'winget'
$node = Resolve-Tool -Name 'node'

$gitVersion = $null
if ($git) {
    try { $gitVersion = (@(& $git --version 2>$null) | Select-Object -First 1) } catch { $gitVersion = $null }
}

$missing = @()
if ($hugo.Mode -eq 'none') { $missing += 'hugo' }
if (-not $git) { $missing += 'git' }

# exit code: 0 ready, 1 hugo missing, 2 git missing, 3 both missing
$exitCode = 0
if ($missing -contains 'hugo') { $exitCode += 1 }
if ($missing -contains 'git') { $exitCode += 2 }

if ($Json) {
    [pscustomobject]@{
        hugoMode     = $hugo.Mode
        hugoExe      = $hugo.Exe
        hugoVersion  = $hugo.Version
        gitExe       = $git
        gitVersion   = $gitVersion
        dockerClient = $docker.Client
        dockerEngine = $docker.Engine
        dockerVer    = $docker.Version
        winget       = [bool]$winget
        node         = [bool]$node
        result       = $(if ($missing.Count -eq 0) { 'READY' } else { ($missing -join '+').ToUpper() + '_MISSING' })
    } | ConvertTo-Json
    exit $exitCode
}

Write-Output '=== hugo-blog-manager env check ==='
Write-Output ("[hugo]    {0}" -f $(switch ($hugo.Mode) {
        'native' { "{0}  -> {1}" -f ($hugo.Version), $hugo.Exe }
        'docker' { 'not installed natively, but Docker engine is UP (container fallback ready)' }
        default  { 'NOT FOUND' }
    }))
Write-Output ("[docker]  client={0} engine={1} {2}" -f $docker.Client, $docker.Engine, $(if ($docker.Version) { "($($docker.Version))" } else { '' }))
Write-Output ("[git]     {0}" -f $(if ($git) { "$gitVersion  -> $git" } else { 'NOT FOUND' }))
Write-Output ("[winget]  {0}" -f $(if ($winget) { $winget } else { 'NOT FOUND' }))
Write-Output ("[node]    {0}" -f $(if ($node) { 'present' } else { 'absent (not required)' }))
Write-Output ("[scripts] {0}" -f $PSScriptRoot)

if ($missing.Count -eq 0) {
    Write-Output ''
    Write-Output 'RESULT: READY'
    exit $exitCode
}

Write-Output ''
Write-Output ("RESULT: {0}_MISSING" -f ($missing -join '+').ToUpper())
if ($missing -contains 'hugo') {
    Write-Output ''
    Write-Output 'NEXT: hugo is missing. Do NOT install silently - ask the user to pick one:'
    Write-Output '  A) local install  : powershell -NoProfile -File install_hugo.ps1 -Method Local    (winget Hugo.Hugo.Extended)'
    Write-Output '  B) docker install : powershell -NoProfile -File install_hugo.ps1 -Method Docker   (needs Docker Desktop running)'
    Write-Output 'After the user chooses, run the matching command (add -DryRun first to show the command).'
}
if ($missing -contains 'git') {
    Write-Output ''
    Write-Output 'NEXT: git is missing. Expected at F:\Git\cmd\git.exe on this machine.'
}

exit $exitCode
