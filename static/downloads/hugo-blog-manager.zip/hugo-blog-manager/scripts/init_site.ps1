#Requires -Version 5.1
<#
    hugo-blog-manager : create a brand new Hugo site.

    Does: `hugo new site <name> --format yaml` + `git init -b main` + hugo.yaml + .gitignore.
    Requires an empty (or non-existing) target directory. Never overwrites an existing site.

    Usage:
        powershell -NoProfile -File init_site.ps1 -SitePath "D:\blogs\myblog" -Title "My Blog" -DryRun
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$SitePath,
    [Parameter(Mandatory = $true)][string]$Title,
    [string]$BaseUrl = 'https://example.org/',
    [string]$LanguageCode = 'zh-cn',
    [string]$Image = 'hugomods/hugo:exts',
    [switch]$NoGit,
    [switch]$DryRun
)

. (Join-Path $PSScriptRoot '_common.ps1')

$sitePath = [System.IO.Path]::GetFullPath($SitePath)
$parent = Split-Path -Parent $sitePath
$leaf = Split-Path -Leaf $sitePath

if (Test-Path -LiteralPath $sitePath) {
    $entries = @(Get-ChildItem -LiteralPath $sitePath -Force | Where-Object { $_.Name -ne '.' })
    if ($entries.Count -gt 0) {
        Write-Fail "Target directory is not empty: $sitePath. Pick another path, or clean it up first (refusing to touch existing content)." 4
    }
}
else {
    if ($DryRun) { Write-Output "DRY-RUN: New-Item -ItemType Directory -Force -Path `"$parent`"" }
    else { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
}

# 1. hugo new site (runs in the parent dir so both native and docker mode work)
Invoke-Hugo -SitePath $parent -MountPath $parent -Image $Image -DryRun:$DryRun `
    -HugoArgs @('new', 'site', $leaf, '--format', 'yaml')

if ($DryRun) {
    Write-Output ("DRY-RUN: write {0}" -f (Join-Path $sitePath 'hugo.yaml'))
    Write-Output ("DRY-RUN: write {0}" -f (Join-Path $sitePath '.gitignore'))
    if (-not $NoGit) { Write-Output ("DRY-RUN: git -C `"{0}`" init -b main" -f $sitePath) }
    exit 0
}

if (-not (Test-Path -LiteralPath $sitePath)) {
    Write-Fail "hugo reported success but $sitePath does not exist." 1
}

# 2. site config. A fresh site has nothing to preserve, so a clean hugo.yaml is safe here.
#    `theme:` is intentionally NOT set - install_theme.ps1 adds it once the user picks a theme.
$configPath = Join-Path $sitePath 'hugo.yaml'
$config = @"
baseURL: "$BaseUrl"
languageCode: "$LanguageCode"
title: "$Title"
"@
New-Utf8File -Path $configPath -Content $config
Write-Output "wrote $configPath"

# 3. .gitignore so the build output never lands in git
$gitignore = @'
public/
resources/_gen/
.hugo_build.lock
'@
New-Utf8File -Path (Join-Path $sitePath '.gitignore') -Content $gitignore
Write-Output "wrote $(Join-Path $sitePath '.gitignore')"

# 4. git init
if (-not $NoGit) {
    $git = Get-GitExe
    if (-not $git) {
        Write-Output 'WARNING: git not found - skipping git init. Install git before pushing to GitHub.'
    }
    else {
        Write-Output ("RUN: git -C `"{0}`" init -b main" -f $sitePath)
        & $git -C $sitePath init -b main 2>&1 | ForEach-Object { Write-Output $_ }
    }
}

Write-Output ''
Write-Output "OK: site created at $sitePath"
Write-Output 'NEXT: ask the user which theme to use, then run install_theme.ps1.'
