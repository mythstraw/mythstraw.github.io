#Requires -Version 5.1
<#
    hugo-blog-manager : install the Hugo executable itself.

    ALWAYS ask the user which method they want before running this:
        -Method Local   -> winget install Hugo.Hugo.Extended (hugo.exe on PATH)
        -Method Docker  -> pull a hugo image, used through `docker run` (nothing on PATH)

    Exit codes: 0 ok, 2 prerequisite missing / engine unavailable, 1 unexpected failure.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('Local', 'Docker')]
    [string]$Method,

    [string]$Image = 'hugomods/hugo:exts',
    [string]$WingetId = 'Hugo.Hugo.Extended',
    [switch]$StartEngine,
    [switch]$DryRun
)

. (Join-Path $PSScriptRoot '_common.ps1')

$existing = Get-HugoStatus
if ($existing.Mode -eq 'native') {
    Write-Output ("hugo is already installed: {0} -> {1}" -f $existing.Version, $existing.Exe)
    Write-Output 'Nothing to do.'
    exit 0
}

if ($Method -eq 'Local') {
    $winget = Resolve-Tool -Name 'winget'
    if (-not $winget) {
        Write-Fail 'winget not found. Install it (App Installer) or download Hugo manually.' 2
    }

    $wgArgs = @('install', '--id', $WingetId, '-e', '--accept-source-agreements', '--accept-package-agreements')
    if ($DryRun) {
        Write-Output ('DRY-RUN: {0} {1}' -f $winget, ($wgArgs -join ' '))
        Write-Output 'DRY-RUN: then re-run check_env.ps1 to verify hugo is visible on PATH.'
        exit 0
    }

    Write-Output ("RUN: {0} {1}" -f $winget, ($wgArgs -join ' '))
    & $winget @wgArgs
    $code = $LASTEXITCODE
    Write-Output ("winget exit code: {0}" -f $code)

    $after = Get-HugoStatus
    if ($after.Mode -eq 'native') {
        Write-Output ("OK: hugo {0} -> {1}" -f $after.Version, $after.Exe)
        exit 0
    }
    if ($after.Mode -eq 'docker') {
        Write-Output 'Hugo is still not a native executable, but the Docker engine is up, so container mode works.'
        Write-Output 'Note: a newly installed hugo.exe may need a fresh shell/refresh of PATH before it is visible.'
        exit 0
    }
    Write-Fail ("winget finished (exit {0}) but hugo is still not resolvable. If the download URL was blocked, retry once the accelerator/proxy is up, or use -Method Docker." -f $code) 1
}

# ---------------- Docker ----------------
$docker = Get-DockerExe
if (-not $docker) {
    Write-Fail 'docker CLI not found. Install/start Docker Desktop first, then re-run.' 2
}

$engine = Test-DockerEngine
if (-not $engine.Engine) {
    if ($StartEngine) {
        $desktop = 'C:\Program Files\Docker\Docker\Docker Desktop.exe'
        if (-not (Test-Path -LiteralPath $desktop)) { Write-Fail "Docker Desktop not found at $desktop" 2 }
        if ($DryRun) {
            Write-Output ("DRY-RUN: Start-Process '{0}'" -f $desktop)
            Write-Output ('DRY-RUN: wait up to 240s for the engine, then: {0} pull {1}' -f $docker, $Image)
            exit 0
        }
        Write-Output ("Starting Docker Desktop: {0}" -f $desktop)
        Start-Process -FilePath $desktop | Out-Null
        $deadline = (Get-Date).AddSeconds(240)
        while ((Get-Date) -lt $deadline) {
            Start-Sleep -Seconds 6
            if ((Test-DockerEngine).Engine) { break }
            Write-Output '... waiting for Docker engine'
        }
        if (-not (Test-DockerEngine).Engine) {
            Write-Fail 'Docker engine did not come up within 240s. Start Docker Desktop manually and retry.' 2
        }
    }
    else {
        Write-Output 'The Docker CLI exists but the engine is NOT running (npipe not reachable).'
        Write-Output 'Ask the user to start Docker Desktop, or re-run with -StartEngine.'
        exit 2
    }
}

$pullArgs = @('pull', $Image)
if ($DryRun) {
    Write-Output ('DRY-RUN: {0} {1}' -f $docker, ($pullArgs -join ' '))
    Write-Output ('DRY-RUN: {0} run --rm {1} hugo version' -f $docker, $Image)
    exit 0
}

Write-Output ("RUN: {0} {1}" -f $docker, ($pullArgs -join ' '))
& $docker @pullArgs
if ($LASTEXITCODE -ne 0) {
    Write-Output 'pull failed. If the registry is unreachable, check the registry-mirrors in %USERPROFILE%\.docker\daemon.json, or ask the user to enable the accelerator.'
}

Write-Output ''
Write-Output ("Verifying: {0} run --rm {1} hugo version" -f $docker, $Image)
& $docker run --rm $Image hugo version

Write-Output ''
Write-Output 'Docker mode ready. The other scripts detect it automatically and will run hugo via:'
Write-Output ('  docker run --rm -v "<site>:/src" -w /src {0} hugo <args>' -f $Image)
exit 0
