#Requires -Version 5.1
<#
    hugo-blog-manager : write .github/workflows/hugo.yaml (build + deploy to GitHub Pages),
    commit it and push.

    The Hugo version is never hard-coded: it is taken from -HugoVersion, or detected from the
    local hugo / the hugo container, so the CI build matches the version used locally.

    Usage:
        powershell -NoProfile -File setup_actions.ps1 -SitePath "D:\blogs\myblog" -DryRun
        powershell -NoProfile -File setup_actions.ps1 -SitePath "D:\blogs\myblog" -HugoVersion 0.166.0
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$SitePath,
    [string]$HugoVersion = '',
    [string]$Branch = 'main',
    [string]$Message = 'Add GitHub Actions workflow for auto deploy',
    [string]$Image = 'hugomods/hugo:exts',
    [switch]$NoPush,
    [switch]$DryRun
)

. (Join-Path $PSScriptRoot '_common.ps1')

$sitePath = [System.IO.Path]::GetFullPath($SitePath)
if (-not (Test-Path -LiteralPath $sitePath)) { Write-Fail "Site not found: $sitePath" 4 }

# --- resolve the Hugo version ----------------------------------------------
function Get-HugoVersionFromString {
    param([string]$Text)
    if (-not $Text) { return $null }
    if ($Text -match '(\d+\.\d+\.\d+)') { return $matches[1] }
    return $null
}

if (-not $HugoVersion) {
    $status = Get-HugoStatus
    if ($status.Mode -eq 'native') {
        $HugoVersion = Get-HugoVersionFromString -Text $status.Version
    }
    elseif ($status.Mode -eq 'docker') {
        Write-Output ("Detecting version: docker run --rm {0} hugo version" -f $Image)
        $raw = @(& $status.Exe run --rm $Image hugo version 2>$null) -join ' '
        $HugoVersion = Get-HugoVersionFromString -Text $raw
    }
}
if ($HugoVersion -and $HugoVersion -notmatch '^\d+\.\d+(\.\d+)?$') {
    Write-Fail ("Invalid -HugoVersion '{0}'. Expected a plain version such as 0.166.0 (CI downloads hugo_extended_<version>_linux-amd64.deb)." -f $HugoVersion) 4
}
if (-not $HugoVersion) {
    Write-Fail 'Could not determine the Hugo version. Ask the user, or install hugo first, then pass -HugoVersion x.y.z.' 4
}
Write-Output ("Hugo version for CI: {0}" -f $HugoVersion)

$template = @'
name: Deploy Hugo site to Pages

on:
  push:
    branches: ["__BRANCH__"]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: pages
  cancel-in-progress: false

defaults:
  run:
    shell: bash

jobs:
  build:
    runs-on: ubuntu-latest
    env:
      HUGO_VERSION: "__HUGO_VERSION__"
    steps:
      - name: Install Hugo CLI
        run: |
          wget -O ${{ runner.temp }}/hugo.deb https://github.com/gohugoio/hugo/releases/download/v${HUGO_VERSION}/hugo_extended_${HUGO_VERSION}_linux-amd64.deb \
          && sudo dpkg -i ${{ runner.temp }}/hugo.deb
      - name: Checkout
        uses: actions/checkout@v4
        with:
          submodules: recursive
          fetch-depth: 0
      - name: Setup Pages
        id: pages
        uses: actions/configure-pages@v5
      - name: Build with Hugo
        env:
          HUGO_CACHEDIR: ${{ runner.temp }}/hugo_cache
          HUGO_ENVIRONMENT: production
        run: |
          hugo --minify --baseURL "${{ steps.pages.outputs.base_url }}/"
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: ./public

  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    needs: build
    steps:
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
'@

$workflow = $template.Replace('__HUGO_VERSION__', $HugoVersion).Replace('__BRANCH__', $Branch)
$workflowPath = Join-Path $sitePath (Join-Path '.github\workflows' 'hugo.yaml')

if ($DryRun) {
    Write-Output ("DRY-RUN: write {0} ({1} chars)" -f $workflowPath, $workflow.Length)
    Write-Output ('DRY-RUN: git -C "{0}" add .github/workflows/hugo.yaml; commit -m "{1}"' -f $sitePath, $Message)
    if (-not $NoPush) { Write-Output "DRY-RUN: push (via push_github.ps1)" }
    exit 0
}

New-Utf8File -Path $workflowPath -Content $workflow
Write-Output "wrote $workflowPath"

if ($NoPush) {
    Write-Output 'Skipping commit/push (-NoPush).'
    exit 0
}

$git = Get-GitExe
if (-not $git) { Write-Fail 'git not found - workflow written but not committed.' 2 }

$remote = (& $git -C $sitePath remote get-url origin 2>$null)
if (-not $remote) { Write-Fail 'No origin remote configured. Run push_github.ps1 -RepoUrl <url> first.' 4 }

& (Join-Path $PSScriptRoot 'push_github.ps1') -SitePath $sitePath -RepoUrl $remote -Branch $Branch -Message $Message
exit $LASTEXITCODE
