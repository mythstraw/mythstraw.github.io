#Requires -Version 5.1
<#
    hugo-blog-manager : install a theme into an existing site and wire it up in hugo.yaml.

    This script deliberately has NO default theme. Ask the user which theme they want,
    then pass its name + repo URL here.

    -Mode Submodule : git submodule add (preferred; keeps the theme updatable)
    -Mode Zip       : download a zip archive (use when github.com is unreachable),
                      e.g. -Mode Zip -ZipUrl "https://<mirror>/archive/refs/heads/main.zip"

    Usage:
        powershell -NoProfile -File install_theme.ps1 -SitePath "D:\blogs\myblog" `
            -ThemeName PaperMod -ThemeRepo https://github.com/adityatelange/hugo-PaperMod.git -DryRun
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$SitePath,
    [Parameter(Mandatory = $true)][string]$ThemeName,
    [Parameter(Mandatory = $true)][string]$ThemeRepo,
    [ValidateSet('Submodule', 'Zip')][string]$Mode = 'Submodule',
    [string]$ZipUrl = '',
    [switch]$Force,
    [switch]$DryRun
)

. (Join-Path $PSScriptRoot '_common.ps1')

$sitePath = [System.IO.Path]::GetFullPath($SitePath)
if (-not (Test-Path -LiteralPath $sitePath)) { Write-Fail "Site not found: $sitePath" 4 }

$configPath = @('hugo.yaml', 'hugo.yml', 'hugo.toml', 'config.yaml', 'config.toml') |
    ForEach-Object { Join-Path $sitePath $_ } |
    Where-Object { Test-Path -LiteralPath $_ } |
    Select-Object -First 1
if (-not $configPath) { Write-Fail "No hugo config file found in $sitePath (expected hugo.yaml)." 4 }

$themeDir = Join-Path $sitePath (Join-Path 'themes' $ThemeName)
if (Test-Path -LiteralPath $themeDir) {
    if (-not $Force) { Write-Fail "Theme directory already exists: $themeDir. Use -Force to replace it." 4 }
    if ($DryRun) { Write-Output "DRY-RUN: Remove-Item -Recurse -Force `"$themeDir`"" }
    else { Remove-Item -LiteralPath $themeDir -Recurse -Force }
}

$git = Get-GitExe

if ($Mode -eq 'Submodule') {
    if (-not $git) { Write-Fail 'git not found - cannot add a submodule. Use -Mode Zip instead.' 2 }
    if (-not (Test-Path -LiteralPath (Join-Path $sitePath '.git'))) {
        Write-Fail "Not a git repository: $sitePath (run init_site.ps1 first, or use -Mode Zip)." 4
    }

    if (-not $DryRun) {
        Write-Output ("Checking reachability: git ls-remote {0} HEAD" -f $ThemeRepo)
        $probe = & $git ls-remote $ThemeRepo HEAD 2>&1
        if ($LASTEXITCODE -ne 0) {
            Write-Output 'Unreachable. Common causes on this machine:'
            Write-Output '  - the accelerator (Steam++ / Watt Toolkit) is not running, while hosts points github.com to 127.0.0.1'
            Write-Output '  - no proxy / mirror is configured'
            Write-Output 'Ask the user: start the accelerator and retry, or use -Mode Zip with a mirrored ZipUrl.'
            Write-Fail "Cannot reach $ThemeRepo" 3
        }
        Write-Output ("  ok: {0}" -f (@($probe)[0]))
    }

    $subArgs = @('-C', $sitePath, 'submodule', 'add', $ThemeRepo, "themes/$ThemeName")
    if ($DryRun) { Write-Output ('DRY-RUN: git ' + ($subArgs -join ' ')) }
    else {
        Write-Output ('RUN: git ' + ($subArgs -join ' '))
        & $git @subArgs
        if ($LASTEXITCODE -ne 0) { Write-Fail 'git submodule add failed.' 1 }
        & $git -C $sitePath submodule update --init --recursive
    }
}
else {
    if (-not $ZipUrl) { Write-Fail '-Mode Zip requires -ZipUrl (a downloadable theme archive).' 4 }
    if ($DryRun) {
        Write-Output ('DRY-RUN: Invoke-WebRequest ' + $ZipUrl + ' -> temp zip; Expand-Archive; move contents to ' + $themeDir)
    }
    else {
        $tmpZip = Join-Path $env:TEMP ("theme-{0}.zip" -f $ThemeName)
        $tmpDir = Join-Path $env:TEMP ("theme-{0}" -f $ThemeName)
        Write-Output "Downloading $ZipUrl"
        try {
            Invoke-WebRequest -Uri $ZipUrl -OutFile $tmpZip -UseBasicParsing -TimeoutSec 300
        }
        catch {
            Write-Output "download failed: $($_.Exception.Message)"
            Write-Fail "Could not download $ZipUrl. Check the URL / mirror, or ask the user to enable the accelerator and retry." 3
        }
        Remove-Item -LiteralPath $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
        try {
            Expand-Archive -LiteralPath $tmpZip -DestinationPath $tmpDir -Force
        }
        catch {
            Remove-Item -LiteralPath $tmpZip -Force -ErrorAction SilentlyContinue
            Write-Fail "Downloaded file is not a readable zip archive: $ZipUrl" 3
        }
        $root = @(Get-ChildItem -LiteralPath $tmpDir -Directory)
        if ($root.Count -ne 1) { Write-Fail "Unexpected archive layout (expected a single top-level folder) in $tmpZip" 1 }
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $themeDir) | Out-Null
        Move-Item -LiteralPath $root[0].FullName -Destination $themeDir
        Remove-Item -LiteralPath $tmpZip, $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
        Write-Output "extracted to $themeDir"
    }
}

# wire the theme into the site config
$ext = [System.IO.Path]::GetExtension($configPath).ToLower()
$content = Get-Content -LiteralPath $configPath -Raw
if ($ext -eq '.yaml' -or $ext -eq '.yml') { $line = "theme: `"$ThemeName`"" }
else { $line = "theme = `"$ThemeName`"" }

if ($content -match '(?m)^\s*theme\s*[:=]') {
    $newContent = [regex]::Replace($content, '(?m)^\s*theme\s*[:=].*$', $line)
    $action = "replaced existing theme setting in"
}
else {
    $newContent = $content.TrimEnd() + "`n" + $line + "`n"
    $action = "added theme setting to"
}

if ($DryRun) {
    Write-Output ("DRY-RUN: {0} {1} -> {2}" -f $action, $configPath, $line)
    Write-Output ('DRY-RUN: then preview with preview.ps1 -SitePath "' + $sitePath + '"')
}
else {
    New-Utf8File -Path $configPath -Content $newContent
    Write-Output ("{0} {1} -> {2}" -f $action, $configPath, $line)
    Write-Output ''
    Write-Output ('OK: theme {0} installed.' -f $ThemeName)
    Write-Output 'NEXT: run preview.ps1 and let the user confirm in the browser before pushing.'
}
