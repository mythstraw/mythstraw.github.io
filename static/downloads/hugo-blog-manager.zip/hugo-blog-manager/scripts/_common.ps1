# hugo-blog-manager : shared helpers
# ASCII-only on purpose (avoid encoding problems on Windows consoles).
# Dot-source from other scripts:  . (Join-Path $PSScriptRoot '_common.ps1')

$ErrorActionPreference = 'Continue'

function Resolve-Tool {
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [string[]]$Fallback = @()
    )
    $cmd = Get-Command -Name $Name -CommandType Application -ErrorAction SilentlyContinue |
        Select-Object -First 1
    if ($cmd) { return $cmd.Source }
    foreach ($p in $Fallback) {
        if ($p -and (Test-Path -LiteralPath $p)) { return (Resolve-Path -LiteralPath $p).Path }
    }
    return $null
}

function Get-GitExe {
    return Resolve-Tool -Name 'git' -Fallback @(
        'F:\Git\cmd\git.exe',
        'C:\Program Files\Git\cmd\git.exe',
        "$env:LOCALAPPDATA\Programs\Git\cmd\git.exe"
    )
}

function Get-DockerExe {
    return Resolve-Tool -Name 'docker' -Fallback @(
        'C:\Program Files\Docker\Docker\resources\bin\docker.exe'
    )
}

# Returns @{ Client = <bool>; Engine = <bool>; Version = <string|null> }
function Test-DockerEngine {
    $exe = Get-DockerExe
    if (-not $exe) { return @{ Client = $false; Engine = $false; Version = $null } }
    $ver = $null
    try {
        $out = & $exe version --format '{{.Server.Version}}' 2>$null
        if ($LASTEXITCODE -eq 0 -and $out) { $ver = @($out)[0].ToString().Trim() }
    }
    catch { $ver = $null }
    return @{ Client = $true; Engine = [bool]$ver; Version = $ver }
}

# Returns @{ Mode = 'native'|'docker'|'none'; Exe = <string|null>; Version = <string|null> }
function Get-HugoStatus {
    $native = Resolve-Tool -Name 'hugo' -Fallback @(
        "$env:LOCALAPPDATA\Microsoft\WinGet\Links\hugo.exe",
        'F:\Program Files\Hugo\hugo.exe'
    )
    if ($native) {
        $v = $null
        try { $v = (@(& $native version 2>$null) | Select-Object -First 1) } catch { $v = $null }
        return @{ Mode = 'native'; Exe = $native; Version = $v }
    }
    $dk = Test-DockerEngine
    if ($dk.Engine) { return @{ Mode = 'docker'; Exe = (Get-DockerExe); Version = $null } }
    return @{ Mode = 'none'; Exe = $null; Version = $null }
}

function ConvertTo-PosixPath {
    param([Parameter(Mandatory = $true)][string]$Path)
    $full = ([System.IO.Path]::GetFullPath($Path)) -replace '\\', '/'
    if ($full -match '^([A-Za-z]):(.*)$') { return ('/{0}{1}' -f $matches[1].ToLower(), $matches[2]) }
    return $full
}

function New-Utf8File {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Content
    )
    $dir = Split-Path -Parent $Path
    if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Content, $utf8)
}

# Run hugo either natively or inside a container, so both install methods work.
# -MountPath: host dir mounted as /src when using Docker (defaults to $SitePath).
function Invoke-Hugo {
    param(
        [Parameter(Mandatory = $true)][string]$SitePath,
        [Parameter(Mandatory = $true)][string[]]$HugoArgs,
        [string]$MountPath = '',
        [string]$Image = 'hugomods/hugo:exts',
        [string[]]$ExtraDockerArgs = @(),
        [switch]$DryRun
    )
    $status = Get-HugoStatus
    if ($status.Mode -eq 'native') {
        $line = ('cd "{0}"; hugo {1}' -f $SitePath, ($HugoArgs -join ' '))
        if ($DryRun) { Write-Output "DRY-RUN: $line"; return }
        Write-Output "RUN: $line"
        Push-Location -LiteralPath $SitePath
        try {
            & $status.Exe @HugoArgs
            if ($LASTEXITCODE -ne 0) { throw "hugo exited with code $LASTEXITCODE" }
        }
        finally { Pop-Location }
        return
    }
    if ($status.Mode -eq 'docker') {
        $mount = $MountPath; if (-not $mount) { $mount = $SitePath }
        $src = ConvertTo-PosixPath $mount
        $dkArgs = @('run', '--rm') + $ExtraDockerArgs + @('-v', "${src}:/src", '-w', '/src', $Image, 'hugo') + $HugoArgs
        $line = ('docker ' + ($dkArgs -join ' '))
        if ($DryRun) { Write-Output "DRY-RUN: $line"; return }
        Write-Output "RUN: $line"
        & $status.Exe @dkArgs
        if ($LASTEXITCODE -ne 0) { throw "docker hugo exited with code $LASTEXITCODE" }
        return
    }
    throw "hugo is not available: neither a native 'hugo' executable nor a running Docker engine was found. Run install_hugo.ps1 first (ask the user to choose Local or Docker)."
}

function Write-Fail {
    param([Parameter(Mandatory = $true)][string]$Message, [int]$Code = 1)
    Write-Output "ERROR: $Message"
    exit $Code
}
