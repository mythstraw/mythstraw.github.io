#Requires -Version 5.1
<#
    hugo-blog-manager : commit the site and push it to GitHub (also used as the "save" step
    after flow B edits).

    Safety behaviour:
      - aborts when git identity is not configured (never commits as an unknown author)
      - aborts when the remote already has commits and -Rebase was not given
      - tolerates an empty working tree (nothing to commit)
      - GIT_TERMINAL_PROMPT=0 so a missing credential fails fast instead of hanging
        (Git Credential Manager can still show its own dialog)

    Usage:
        powershell -NoProfile -File push_github.ps1 -SitePath "D:\blogs\myblog" `
            -RepoUrl https://github.com/<user>/<repo>.git -DryRun
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$SitePath,
    [Parameter(Mandatory = $true)][string]$RepoUrl,
    [string]$Branch = 'main',
    [string]$Message = 'Update site',
    [string]$GitUserName = '',
    [string]$GitUserEmail = '',
    [switch]$Rebase,
    [switch]$DryRun
)

. (Join-Path $PSScriptRoot '_common.ps1')

$sitePath = [System.IO.Path]::GetFullPath($SitePath)
if (-not (Test-Path -LiteralPath $sitePath)) { Write-Fail "Site not found: $sitePath" 4 }

$git = Get-GitExe
if (-not $git) { Write-Fail 'git not found.' 2 }
if (-not (Test-Path -LiteralPath (Join-Path $sitePath '.git'))) {
    Write-Fail "Not a git repository: $sitePath (run init_site.ps1 first)." 4
}

function Invoke-Git {
    param([Parameter(Mandatory = $true)][string[]]$GitArgs, [switch]$AllowFail)
    Write-Output ('RUN: git ' + ($GitArgs -join ' '))
    $out = & $git @GitArgs 2>&1
    $script:LastGitCode = $LASTEXITCODE
    if ($out) { $out | ForEach-Object { Write-Output ('  ' + $_) } }
    if ($script:LastGitCode -ne 0 -and -not $AllowFail) {
        Write-Fail ("git {0} failed (exit {1})." -f $GitArgs[0], $script:LastGitCode) 1
    }
}

# --- git identity -----------------------------------------------------------
$email = (& $git -C $sitePath config user.email 2>$null)
if (-not $email) { $email = (& $git -C $sitePath config --global user.email 2>$null) }
$name = (& $git -C $sitePath config user.name 2>$null)
if (-not $name) { $name = (& $git -C $sitePath config --global user.name 2>$null) }

if (-not $email -or -not $name) {
    if ($GitUserEmail -and $GitUserName) {
        if ($DryRun) { Write-Output ("DRY-RUN: git -C `"{0}`" config user.name `"{1}`" / user.email `"{2}`"" -f $sitePath, $GitUserName, $GitUserEmail) }
        else {
            Invoke-Git -GitArgs @('-C', $sitePath, 'config', 'user.name', $GitUserName)
            Invoke-Git -GitArgs @('-C', $sitePath, 'config', 'user.email', $GitUserEmail)
        }
    }
    else {
        Write-Fail 'git user.name / user.email are not configured. Ask the user for them and re-run with -GitUserName / -GitUserEmail.' 4
    }
}

# --- remote -----------------------------------------------------------------
$existingRemote = (& $git -C $sitePath remote get-url origin 2>$null)
if ($existingRemote) {
    if ($existingRemote -ne $RepoUrl) {
        if ($DryRun) { Write-Output ("DRY-RUN: git -C `"{0}`" remote set-url origin {1}" -f $sitePath, $RepoUrl) }
        else { Invoke-Git -GitArgs @('-C', $sitePath, 'remote', 'set-url', 'origin', $RepoUrl) }
    }
    else { Write-Output "origin already points at $RepoUrl" }
}
else {
    if ($DryRun) { Write-Output ("DRY-RUN: git -C `"{0}`" remote add origin {1}" -f $sitePath, $RepoUrl) }
    else { Invoke-Git -GitArgs @('-C', $sitePath, 'remote', 'add', 'origin', $RepoUrl) }
}

if ($DryRun) {
    Write-Output ("DRY-RUN: git -C `"{0}`" add -A" -f $sitePath)
    Write-Output ("DRY-RUN: git -C `"{0}`" commit -m `"{1}`"  (skipped when the tree is clean)" -f $sitePath, $Message)
    Write-Output ("DRY-RUN: git -C `"{0}`" ls-remote --heads origin {1}   (non-empty remote => needs -Rebase)" -f $sitePath, $Branch)
    Write-Output ("DRY-RUN: git -C `"{0}`" push -u origin {1}" -f $sitePath, $Branch)
    exit 0
}

# --- local commit -----------------------------------------------------------
$status = (& $git -C $sitePath status --porcelain 2>$null)
if ($status) {
    Invoke-Git -GitArgs @('-C', $sitePath, 'add', '-A')
    Invoke-Git -GitArgs @('-C', $sitePath, 'commit', '-m', $Message)
}
else {
    Write-Output 'Working tree is clean - nothing to commit.'
}

$env:GIT_TERMINAL_PROMPT = '0'

# --- remote history guard ---------------------------------------------------
$remoteHeads = (& $git ls-remote --heads origin $Branch 2>$null)
if ($remoteHeads -and $LASTEXITCODE -eq 0) {
    Write-Output "Remote branch '$Branch' already has commits."
    if (-not $Rebase) {
        Write-Fail "Remote is not empty. Re-run with -Rebase to pull remote commits first, or push to another repo/branch." 4
    }
    Invoke-Git -GitArgs @('-C', $sitePath, 'pull', '--rebase', 'origin', $Branch)
}

# --- push -------------------------------------------------------------------
Invoke-Git -GitArgs @('-C', $sitePath, 'push', '-u', 'origin', $Branch) -AllowFail
if ($script:LastGitCode -ne 0) {
    Write-Output ''
    Write-Output 'push failed. Check:'
    Write-Output "  - the repository exists and is empty (GitHub -> New repository, do not add a README)"
    Write-Output '  - credentials: Git Credential Manager should prompt; a PAT needs repo scope'
    Write-Output '  - network: github.com is redirected to 127.0.0.1 in hosts on this machine,'
    Write-Output '    so the accelerator (Steam++ / Watt Toolkit) must be running'
    exit $script:LastGitCode
}

Write-Output ''
Write-Output "OK: pushed to $RepoUrl ($Branch)"
Write-Output 'NEXT: GitHub repo -> Settings -> Pages -> Source = "GitHub Actions" (one-time manual step).'
