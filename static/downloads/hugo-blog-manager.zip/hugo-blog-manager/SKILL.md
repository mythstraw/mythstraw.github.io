---
name: hugo-blog-manager
description: 管理 Hugo 博客：从零创建站点、选装主题、推送 GitHub 并配置 GitHub Actions 自动部署到 GitHub Pages；以及安全地修改现有站点的内容、Front Matter、布局、样式和配置（改页脚/导航/关于页/短代码/自定义 CSS，先给 diff 再逐步确认，hugo server 本地预览，构建或发布失败排错）。当用户说"部署 Hugo 博客""新建 Hugo 站点""创建博客""装主题/换主题""修改 Hugo 页面""改页脚""加关于页""博客发不出去/Pages 404"或提到 Hugo、GitHub Pages、hugo.yaml 时使用。安装 Hugo 本体必须先让用户在"本地安装 / Docker 安装"之间选择；主题必须在安装那一刻现场询问用户。
metadata:
  nanobot:
    emoji: 📝
    requires:
      bins: ["git"]
---

# Hugo 博客管理器

两个工作流：**流程 A 部署新博客**、**流程 B 安全修改现有站点**。

脚本目录（下文记作 `$S`，调用时把 `$S` 替换成这个真实路径）：

```
$S = D:\nanobot\workspace\skills\hugo-blog-manager\scripts
```

运行时的当前目录不是技能目录，**调用脚本必须用绝对路径**。
全部脚本是 PowerShell（Windows 原生，不依赖 WSL / Git Bash），且每个都支持 `-DryRun`：只打印将要执行的命令，不做任何改动。

## 两条硬性规则

1. **Hugo 本体安装必须先问用户**。只能通过 `install_hugo.ps1`，且必须在用户明确选择「本地安装」（winget `Hugo.Hugo.Extended`）或「Docker 安装」（拉 hugo 镜像，用 `docker run` 跑）之后才执行。不要自动安装，不要替用户选，不要在用户未表态时开跑。
2. **主题必须现场问用户**。本技能不预设任何主题。走到装主题那一步时，先给 3~4 个候选（各自特点 + 仓库地址）让用户挑，选定后才跑 `install_theme.ps1`。

## 确认式执行

每个关键节点三步走：先跑 `-DryRun` → 把命令和影响讲给用户 → 用户明确同意后去掉 `-DryRun` 实跑。

---

## 全局前置检查

```powershell
powershell -NoProfile -File "$S\check_env.ps1"
```

只读体检（hugo / git / docker / winget），退出码 0=就绪、1=hugo 缺失、2=git 缺失、3=两者都缺。
hugo 缺失时**不要自己装**，转去问用户选哪种方式：

```powershell
powershell -NoProfile -File "$S\install_hugo.ps1" -Method Local  -DryRun   # 本地安装
powershell -NoProfile -File "$S\install_hugo.ps1" -Method Docker -DryRun   # Docker 安装（需 Docker Desktop 运行中，可加 -StartEngine 尝试拉起）
```

装完重跑 `check_env.ps1` 确认。本地安装后若 `hugo` 仍不可见，提醒用户新开终端刷新 PATH。

---

## 流程 A：部署新博客

按顺序走，每步先 DryRun 再等确认。

1. **环境检查** —— 见上。
2. **确定站点位置与标题** —— 问用户博客放哪个目录、叫什么名字（`baseURL` 后续可改）。
3. **创建站点**
   `init_site.ps1 -SitePath "<目录>" -Title "<标题>"` → `hugo new site --format yaml` + `git init -b main` + 写 `hugo.yaml` + `.gitignore`。目标目录必须为空，脚本拒绝覆盖已有内容。
4. **选主题（必须先问用户）** → `install_theme.ps1 -SitePath "<目录>" -ThemeName <名> -ThemeRepo <仓库地址>`
   默认走 `git submodule`（主题可后续升级）；github 不可达时脚本会报错并提示改用 `-Mode Zip -ZipUrl <镜像 zip 地址>`。
   ⚠️ 走 submodule 时，目标 GitHub 仓库必须是还没建或为空的，否则推送冲突。
5. **本地预览，交给用户确认** —— `preview.ps1 -SitePath "<目录>"`（`hugo server`，默认 http://127.0.0.1:1313/）。
   这是前台长进程，用后台会话跑；**界面效果必须由用户在浏览器确认**，不要用 HTTP 探测 localhost 代替。
6. **建 GitHub 仓库**（让用户在网页端建，**不要勾 README / .gitignore**），然后
   `push_github.ps1 -SitePath "<目录>" -RepoUrl https://github.com/<user>/<repo>.git -Message "Initial commit: Hugo blog"`
   脚本行为：git 身份检查 → add/commit（工作区干净则跳过）→ 设置 origin → 远端已有提交则中止（除非 `-Rebase`）→ push。
7. **配置自动部署** —— `setup_actions.ps1 -SitePath "<目录>"` 写 `.github/workflows/hugo.yaml` 并推送。
   Hugo 版本自动取自本地 hugo 或 hugo 容器，也可 `-HugoVersion x.y.z` 指定。
8. **收尾** —— 提醒用户去仓库 `Settings → Pages → Source` 选 **GitHub Actions**（一次性手动步骤），之后每次 push 自动发布。

---

## 流程 B：安全修改现有站点

1. **先读再动**。定位改动点：`hugo.yaml`（站点配置）、`content/`（文章 / Front Matter）、`layouts/`（模板覆盖）、`assets/` 与 `static/`（样式、静态资源）、`themes/<主题>/`（主题源码）。
2. **主题是外部代码（submodule），默认不改它内部文件**。优先在站点根目录放同名文件覆盖（Hugo 的 lookup order），例如 `layouts/partials/footer.html`、`assets/css/extended/custom.css`。确实必须改主题内部时，先说明代价（升级会被覆盖，或需要 fork）再决定。
3. **每处改动都是三步**：读原文 → 把 diff（改什么、为什么、影响哪些页面）给用户看 → 等确认 → 再改。一次只改一处，别攒一堆一起改。
4. **改完必看**：`preview.ps1` 让用户在浏览器确认效果；改模板时可用 `-Drafts` 连草稿一起看。
5. **用户认可后再提交**：`push_github.ps1 -SitePath "<目录>" -RepoUrl <origin> -Message "<改了什么>"`。
6. **不可逆操作先备份**：删内容、换主题、改 `baseURL`、重写 git 历史之前，先复制目录或开新分支。

### 常见排错

- **Pages 404 / 页面不更新**：仓库 `Settings → Pages → Source` 必须是 `GitHub Actions`；`baseURL` 与实际域名不一致时由 workflow 的 `--baseURL`（已内置）兜底。
- **样式没生效**：核对主题的 `assets` / `static` 目录结构，以及 `hugo.yaml` 里的 `theme` 值与 `themes/` 下的目录名是否一致。
- **构建失败**：看 Actions 日志；本地 hugo 版本与主题要求不匹配时，用 `setup_actions.ps1 -HugoVersion` 重新生成 workflow。
- **CI 里主题目录是空的**：workflow 的 checkout 已带 `submodules: recursive`；若仍为空，确认 `.gitmodules` 已提交进仓库。
- **用户站点仓库（`<user>.github.io`）**：`baseURL` 必须是根域名（如 `https://mythstraw.github.io/`）；私有仓库开 Pages 需付费，必须 public；Pages 设置页看不到 Source 下拉框、提示「没有经过验证的域名」（Custom domain DNS 验证）都属正常；每次推送伴随一条 `pages build and deployment`（`event=dynamic`）失败记录是旧式 Jekyll 管线噪音，不影响线上。
- **git 凭据**：本机 `credential.helper=manager` 在系统级 `F:/Git/etc/gitconfig`，GCM 在 `F:\Git\mingw64\bin\git-credential-manager.exe`；`push_github.ps1` 设 `GIT_TERMINAL_PROMPT=0`，首次推送无需重新登录。

---

## 流程 C：定制已有主题（中文化 / 明暗切换 / 配色 / 代码块 / 首页）

原则：**只动站点根目录，不碰 `themes/`**。同路径文件优先于主题模板/样式，主题升级不冲突。改完必须重启预览容器（`hugo server` 在 Windows bind mount 上 fsnotify 失效，不重启看不到变化）。

**单语言中文化**
- 新建 `i18n/<语言key>.toml`（key 小写，如 `zh-cn`）；`hugo.yaml` 里 `defaultContentLanguage: "zh-cn"` + `defaultContentLanguageInSubdir: false` + `languages.zh-cn` 段，**段名必须与 i18n 文件名一致**。
- 主题模板里写死的英文（Search / No posts yet / Home / 页脚 / 404 等）用站点根 `layouts/` 同名文件覆盖后改成 `T "key"`。
- 陷阱：整段删掉 `languages` 会让 Hugo 回落到 `en`，界面直接显示 key 名。

**明暗切换（主题只支持 prefers-color-scheme 时）**
- 站点根 `layouts/partials/custom_head.html`：`<head>` 内联防闪脚本 + 覆盖 `html[data-theme="light"]` / `html[data-theme="dark"]` 的 CSS 变量（特异性高于 `:root`）。
- 默认（无 localStorage）不写 `data-theme`，交给主题 `prefers-color-scheme`；点击才固定并写 `localStorage['theme-mode']`；跟随系统时监听 `matchMedia('(prefers-color-scheme: dark)')` 同步图标文字。
- 按钮放 `layouts/partials/nav.html`，用 `.nav-theme{margin-left:auto}` 推到最右。

**代码块浅/深双色（`.chroma`）**
- 症状：浅色模式下代码块"看不见"——Hugo 默认把 Monokai 配色写成行内 style，被主题 `div.highlight code{background-color:var(--bg-color-secondary)}` 盖住（对比度约 1.03）。
- 修法：`hugo.yaml` 加 `markup.highlight.noClasses: false`；`hugo gen chromastyles --style=github` / `--style=github-dark` 生成两份存为 `assets/css/chroma-light.css` 与 `chroma-dark.css`，在 `custom_head.html` 用 `resources.Get` + `| safeCSS` 引入；补 `div.highlight pre code{background-color:transparent}` 与 `div.highlight pre.chroma{background-color:var(--bg-color-secondary);border:1px solid var(--border-color);border-radius:4px}`。
- `chroma-dark.css` 作用域：`html[data-theme="dark"] .chroma …` 与 `@media (prefers-color-scheme: dark){ html:not([data-theme="light"]) .chroma … }`；两份要一起重生成。

**配色 / 首页**
- 配色变量在主题 `style.html` 的 `:root` 与 `@media (prefers-color-scheme: dark)`：`--bg-color-primary|secondary`、`--text-color-primary|secondary|tertiary`、`--link-color`、`--link-visited-color`、`--border-color`、`--width-max`、`--font-primary|secondary`、`--font-size-*`。真换配色须在 `custom_head.html` 里把 4 个分支（`:root,html[data-theme=light]`、`@media(prefers-color-scheme:dark):root`、`html[data-theme=dark]`）一起重写，否则"跟随系统"与"手动锁定"不一致。
- 首页版式：新建站点根 `layouts/index.html` 覆盖主题版（主题版仅 `{{ .Content }}`）；`content/_index.md` 的 front matter 故意不写 `title`（避免 `<title>` 重复）。每日一句可用 `data/*.yaml` + 构建时 `now` 取模，再用内联 JS 按访客本地日期替换。
- 菜单：`hugo.yaml` 的 `menus.main`（`weight` 决定顺序），文案走 `i18n/*.toml` 的 `nav_*`；导航结构在 `layouts/partials/nav.html`。

**点赞 / 表情反应**：主题 `layouts/_default/single.html` 需 `params.upvote: true` **且** `params.upvoteURL` 才渲染按钮。官方后端 Kudos（Cloudflare Workers + D1）：`GET {base}/{entity}` → `{count}`，`GET|POST|DELETE {base}/{entity}/kudos` → `{count,hasKudos}`，`entity` = RelPermalink 去首尾 `/` 后 `/` 换 `:`（首页 `home`）。替代方案 Giscus（需仓库 public）。

## Hugo 陷阱速查

- `T` / `i18n` 返回值会被 HTML 转义 → 翻译串含 `<a>` 时必须 `| safeHTML`。
- 模板内链接用 `.RelPermalink`；`relURL` 在带语言前缀时会重复加前缀。
- 首页 `.Title` 为空 → 判断首页必须用 `.IsHome`（`eq .Title .Site.Title` 会走错分支）。
- front matter 不写 `slug` 时 Hugo 用**标题**（中文标题 → 百分号编码 URL）→ 每篇显式写 `slug`。
- `buildFuture=false`（默认）：`date` 写成未来时间会被整篇跳过，section 列表甚至不生成。
- `disableKinds: ["taxonomy"]` 只关 taxonomy 列表页，term 页（如 `/blog/<标签>/`）仍会生成。
- 用 Docker 跑 hugo 必须把站点子目录挂成工作目录（挂 `/e/:/src` 会报 "Unable to locate config file"）；清理陈旧产物加 `--cleanDestinationDir`。

## 本机验证手法（Docker 模式）

- 构建检查：`docker run --rm -v /e/myblog:/src -v /c/Temp:/out -w /src hugomods/hugo:exts hugo --destination /out/myblog-verify --cleanDestinationDir`，再用 read_file / grep 查产物；运行中的预览容器可直接 `docker exec <容器> hugo --destination /tmp/build --logLevel info` 快速验证。
- 页面效果：无头 Edge `msedge.exe --headless=new --disable-gpu --hide-scrollbars --user-data-dir=C:\Temp\edge-xxx --window-size=900,3600 --screenshot=<png> <url>` + Pillow 逐像素统计；取浏览器计算值可注入 script 把 `getComputedStyle` 写进 `<pre id="probe-report">`，用 `--virtual-time-budget=4000 --dump-dom` 抓回解析。
- 内联 JS 用 `node --check`（本机 `F:\nodejs\node.exe`）+ 桩 DOM 跑功能用例；桩里判断属性缺失用 `getAttribute` 风格 helper。

---

## 脚本清单

| 脚本 | 作用 | 关键参数 |
| --- | --- | --- |
| `check_env.ps1` | 只读环境体检 | `-Json` |
| `install_hugo.ps1` | 安装 hugo（**须用户先选方式**） | `-Method Local\|Docker`、`-StartEngine` |
| `init_site.ps1` | 新建站点 + git init + 配置 + .gitignore | `-SitePath`、`-Title`、`-BaseUrl`、`-LanguageCode` |
| `install_theme.ps1` | 装主题并写入 `theme:`（**主题须现场问用户**） | `-ThemeName`、`-ThemeRepo`、`-Mode Submodule\|Zip`、`-ZipUrl` |
| `preview.ps1` | `hugo server` 本地预览 | `-Port`、`-Drafts`、`-BindAddress` |
| `push_github.ps1` | 提交并推送到 GitHub | `-RepoUrl`、`-Branch`、`-Message`、`-Rebase` |
| `setup_actions.ps1` | 生成 GitHub Actions 部署 workflow | `-HugoVersion`、`-Branch`、`-NoPush` |

---

## 本机环境注意（Windows）

- **hugo 未安装**（本机已选 Docker 模式，用 `hugomods/hugo:exts` 跑）；winget 可装 `Hugo.Hugo.Extended`（扩展版，很多主题的 SCSS 编译必需）。
- **Docker Desktop 已装但引擎常未启动**：选 Docker 方式要先启动它，`install_hugo.ps1 -Method Docker -StartEngine` 会尝试拉起并最多等 240 秒。
- **不要用 `C:\Windows\system32\bash.exe`**（那是 WSL 启动器，不是 Git Bash）；本技能的脚本已全部改为 PowerShell。
- **`github.com` 在 hosts 里被指向 127.0.0.1**，直连依赖加速器（Steam++ / Watt Toolkit）在运行。任何 git 网络操作失败，先让用户确认加速器是否在跑。
- 脚本输出保持纯 ASCII，避免 Windows 控制台 GBK 乱码。
- 本地预览默认端口 1313；Docker 模式下脚本会自动加 `-p 127.0.0.1:1313:1313`，并把容器内 `--bind` 设为 `0.0.0.0`；`preview.ps1 -SitePath E:\myblog -Port 1313` 即此形态。
- **hugo-bearneo 结构**：`permalinks: {blog: "/p/:slug", tags: "/blog/:slug"}` + `disableKinds: ["taxonomy"]`；navbar = Home + `.Site.Menus.main` + 存在 `/blog` 时的 Blog（`header.html` 的 `<nav>`）；页脚 RSS/邮件共用 `params.footer.hideRSSAndEmail`；favicon 走 `params.favicon`；`baseof.html` 在 `style.html` 之后引入 `custom_head.html`/`custom_body.html`（覆盖优先级正确）。
- 该主题的 `layouts/partials/custom_head.html` 缩进为 **3/5/7 空格**（注释）且 `apply_patch` 是原子的——`old_text` 缩进不符会导致整批 patch 失败；不确定时改用 `write_file` 写 Python 脚本做替换更稳。
